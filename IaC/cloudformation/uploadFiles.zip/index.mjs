import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { DynamoDBClient, PutItemCommand } from '@aws-sdk/client-dynamodb';

const bucketName = process.env.BUCKET_NAME;
const region = process.env.REGION;
const tableName = process.env.TABLE_NAME;

const S3client = new S3Client({region: region});
const DBclient = new DynamoDBClient({region: region});

export const handler = async (event) => {

  const { filename, contentType, author, data } = JSON.parse(event.body);

  if (!data) return httpResponse(400, { msg: "No data field inside event" });
  if (!filename || !contentType || !author)
    return httpResponse(400, {
      msg: "Missing Filename, Content-Type or Author",
    });

  
  try {
    await uploadFileToS3(filename, contentType, data);
    await saveMetadataOnDynamoDB(filename, contentType, author);
    return httpResponse(200, { msg: "File uploaded successfully" });
  } catch (err) {
    console.log(err);
    return httpResponse(500, { msg: "Error uploading file" });
  }
};

const httpResponse = (statusCode, body) => ({
  statusCode,
  body: JSON.stringify(body),
});

const uploadFileToS3 = async (filename, contentType, data) => {
  const params = {
    Bucket: bucketName,
    Key: filename,
    Body: Buffer.from(data, 'base64'),
    ContentType: contentType
  };
  const command = new PutObjectCommand(params);
  return S3client.send(command);
};

const saveMetadataOnDynamoDB = (filename, contentType, author) => {
  const params = {
    TableName: tableName,
    Item: {
      filename: { S: filename },
      contentType: { S: contentType },
      author: { S: author },
    },
  };
  const command = new PutItemCommand(params);
  return DBclient.send(command);
};