import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';

const tableName = process.env.TABLE_NAME;
const region = process.env.REGION;
const DBclient = new DynamoDBClient({region: region});

export const handler = async (event) => {
  
  try {
    const results = await scanTable();
    return httpResponse(200, results.Items);
  } catch (err) {
    console.log(err);
    return httpResponse(500, { msg: "Error scanning table" });
  }
};

const httpResponse = (statusCode, body) => ({
  statusCode,
  body: JSON.stringify(body),
});

const scanTable = async () => {
  const params = {
    TableName: tableName,
  };
  const command = new ScanCommand(params);
  return DBclient.send(command);
};